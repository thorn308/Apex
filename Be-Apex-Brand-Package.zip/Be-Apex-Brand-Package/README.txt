BE APEX — BRAND PACKAGE
========================

CONTENTS
--------
brand-guidelines.html        Single-page brand book. Open in any browser.
logos/with-be-apex/          Lockups with the BE APEX wordmark.
logos/without-be-apex/       Skull + tagline (no wordmark).
logos/mark-only/             Skull mark by itself (with bg variants + 4 transparent).
source/                      Original skull silhouettes on transparent bg
                             (in 4 color treatments — drop these into Illustrator,
                             Figma, or your DTP app of choice).

FORMATS
-------
PNG    Raster. With background where applicable; transparent for the 4
       "mark-*-transparent" variants. 16 files.
JPG    Flattened raster, sRGB, quality 0.92. For web/email/social where
       SVG/PNG is not accepted. 12 files. (No JPGs for transparent
       variants — JPG can't encode alpha.)
SVG    Vector master. Scales to any size without quality loss. Use these for
       print, signage, embroidery digitizing, and anywhere quality matters.
       16 files.

A NOTE ON SVG FONTS
-------------------
The SVGs reference Anton (display) and Inter (tagline) via a Google Fonts
@import inside an SVG <style> block. They render perfectly in:
  - Browsers (when embedded inline via <svg> or <object>)
  - Most modern viewers
For maximum fidelity in Illustrator / InDesign / Inkscape / Affinity, install
Anton and Inter on your system first (both are free from Google Fonts):
  https://fonts.google.com/specimen/Anton
  https://fonts.google.com/specimen/Inter

COLOR
-----
Onyx     #0D0D0D   CMYK 60 · 60 · 60 · 100   PMS Black 6 C
Bone     #F4F1EA   CMYK  3 ·  3 ·  8 ·   0   PMS Warm Gray 1 C
Crimson  #9A1F1F   CMYK 20 ·100 ·100 ·  25   PMS 1815 C

MINIMUM SIZE
------------
Web:        24 px
Print:      0.5 in
Embroidery: 1.5 in

VERSION
-------
1.0 · 2026
